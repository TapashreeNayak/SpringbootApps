
select * from department;
insert into department(dept_id,country,dept_name) values(1,'india','IT');
insert into department(dept_id,country,dept_name) values(2,'india','IRI');

select * from Employee;
insert into Employee(id,age,first_name,last_name,middle_name,department_dept_id) values(1,20,'Tapashree','','nayak',1);
