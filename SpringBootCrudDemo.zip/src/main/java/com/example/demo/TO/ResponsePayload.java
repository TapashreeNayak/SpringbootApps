package com.example.demo.TO;

import lombok.Data;

@Data
public class ResponsePayload {
	
	private String status;	
	private String message;	
	private Object results;
	
}
