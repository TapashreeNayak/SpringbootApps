package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.TO.ResponsePayload;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/employee")
	public ResponsePayload postEmployee(@Validated @RequestBody Employee emp) {
		
		ResponsePayload response = new ResponsePayload();
		try {
			employeeService.saveEmployee(emp);
			response.setStatus("200");
			response.setMessage("Employee saved Succeesully");
		} catch (Exception e) {
			response.setStatus("401");
			response.setMessage("ERROR FOUND SAVING EMPLOYEE");
		}
		
		return response;
	}
	
	@GetMapping("/employee/{ID}")
	public ResponsePayload getEmployee(@PathVariable(value="ID") Long id) {
		
		ResponsePayload response = new ResponsePayload();
		try {
			response.setStatus("200");
			Employee emp = employeeService.getEmployee(id);
			if(emp==null)
				response.setMessage("Employee does not exist");
			else			   
			   response.setResults(emp);
		} catch (Exception e) {
			response.setStatus("401");
			response.setMessage("ERROR FOUND FETCHING EMPLOYEE");
		}
		
		return response;
	}
	
	@GetMapping("/employees")
	public ResponsePayload getEmployees() {
		
		ResponsePayload response = new ResponsePayload();
		
		try {
			response.setStatus("200");
			List<Employee> emp = employeeService.getALLEmployee();
			if(emp==null)
				response.setMessage("No Employees exist");
			else			   
			   response.setResults(emp);
		} catch (Exception e) {
			response.setStatus("401");
			response.setMessage("ERROR FOUND FETCHING EMPLOYEE");
		}
		
		return response;
	}
	
	@DeleteMapping("/employee/{ID}")
	public ResponsePayload deleteEmployees(@PathVariable(value="ID") Long id) {
		
		ResponsePayload response = new ResponsePayload();
		
		try {
			response.setStatus("200");
			employeeService.deletEmployee(id);			
			response.setMessage("Employee deleted successfully");
		} catch (Exception e) {
			response.setStatus("401");
			response.setMessage("ERROR FOUND DELETING EMPLOYEE");
		}
		return response;
	}

}
