package com.example.demo.model;

import javax.persistence.Embeddable;

import lombok.Data;

@Embeddable
@Data
public class EmployeeName {

	private String firstName;
	private String middleName;
	private String lastName;
}
