package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


import lombok.Data;


@Entity
@Data
public class Employee {

	@Id
	private Long id;
	private EmployeeName name ;
	private Integer age;
	
	@ManyToOne// This entry creates a dept id in Emp table
	private Department department;
}
