/*package com.example.demo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


import lombok.Data;
import lombok.ToString;

@Data
@Component
@ConfigurationProperties
@PropertySource(value= {"file:./conf/DB_Config.properties"})
public class DbConfig {

	private String postgres_url;
	private String postgres_dbusername;
	private String postgres_password;
	private String postgres_driverName;
}
*/