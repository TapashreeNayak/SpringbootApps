package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void saveEmployee(Employee emp) throws Exception{		
			employeeRepository.save(emp);	
	}
	
	
	public Employee getEmployee(Long  id) throws Exception{		
		Optional<Employee> emp =  employeeRepository.findById(id)	;
		if(emp.isPresent())
			return emp.get();
		else
			return null;
    }
	
	public List<Employee> getALLEmployee() throws Exception{		
		List<Employee> empList =  employeeRepository.findAll()	;		
			return empList;
    }
	
	public void deletEmployee(Long  id) throws Exception{		
		employeeRepository.deleteById(id)	;		
    }
	
}
